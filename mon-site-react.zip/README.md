# mon-site-react

Projet React "MarketPlace WhatsApp" prêt à importer sur GitHub.

Remarque:
- Remplace `homepage` dans package.json par ton pseudo GitHub si tu veux déployer sur GitHub Pages.
- Pour tester localement: `npm install` puis `npm start`.
- Pour déployer: installe `gh-pages` et lance `npm run deploy`.
